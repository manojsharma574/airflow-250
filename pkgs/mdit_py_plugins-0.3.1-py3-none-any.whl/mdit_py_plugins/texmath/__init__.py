from .index import texmath_plugin  # noqa F401
