from .index import footnote_plugin  # noqa: F401
